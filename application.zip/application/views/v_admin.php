<!-- Main START -->
<main>
  <div class="container">
    <h1 class="thin">Dashboard</h1>
    <div id="dashboard">
      <div class="section">
        <p>NOTE: menu yang lain mengikuti ini aja.</p>
      </div>
    </div>
  </div>
  <!-- container END -->
</main>

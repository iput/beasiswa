<!-- Main START -->
<main>
  <div class="container">
    <h1 class="thin">Dashboard</h1>
    <div id="dashboard">
      <div class="section">
        <p>NOTE: Mauris sed erat ac dolor pretium tincidunt in et metus.</p>
      </div>
    </div>
  </div>
  <!-- container END --> 
</main>